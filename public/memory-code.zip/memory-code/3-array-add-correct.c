#include <stdio.h>
#include <stdlib.h>

int* array_add(const int a[], size_t a_length, const int b[], size_t b_length) {
  int* concatenated = calloc(a_length + b_length, sizeof(int));
  size_t length = 0;
  for (size_t i = 0; i < a_length; i++) {
    concatenated[length++] = a[i];
  }
  for (size_t i = 0; i < b_length; i++) {
    concatenated[length++] = b[i];
  }
  return concatenated;
}

int main(void) {
  int a[] = {1, 2, 3};
  int a_length = 3;

  int b[] = {4, 5, 6};
  int b_length = 3;

  int* concatenated = array_add(a, a_length, b, b_length);
  size_t length = a_length + b_length;

  for (size_t i = 0; i < length; i++) {
    printf("%d ", concatenated[i]);
  }
  putchar('\n');

  free(concatenated);
  return 0;
}

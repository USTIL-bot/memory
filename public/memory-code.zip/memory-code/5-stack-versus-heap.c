#include <stdio.h>
#include <stdlib.h>

int main(void) {
  int stack1 = 1;
  int stack2 = 2;
  printf("stack1: %p, stack2: %p\n", &stack1, &stack2);

  int* heap1 = malloc(sizeof(int));
  int* heap2 = malloc(sizeof(int));
  printf("heap1: %p, heap2: %p\n", heap1, heap2);
  free(heap1);
  free(heap2);

  return 0;
}

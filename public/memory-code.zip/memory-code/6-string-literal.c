#include <stdio.h>

const char* hello() {
  const char* s = "Hello, world!";
  return s;
}

int main(void) {
  const char* s = hello();
  puts(s);
  return 0;
}
